from django.apps import AppConfig


class ResumeMakerConfig(AppConfig):
    name = 'resume_maker'
